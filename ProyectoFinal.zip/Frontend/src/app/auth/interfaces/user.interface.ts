export interface User {
  username: string;
  email: string;
  password: string;
  tipo_usuario: string;
  id_equipo: string;
}