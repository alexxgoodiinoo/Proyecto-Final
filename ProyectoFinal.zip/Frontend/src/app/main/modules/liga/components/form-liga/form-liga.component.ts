import { Component } from '@angular/core';

@Component({
  selector: 'app-form-liga-page',
  standalone: false,
  templateUrl: './form-liga.component.html',
  styles: ``
})
export class FormLigaComponent {

}
