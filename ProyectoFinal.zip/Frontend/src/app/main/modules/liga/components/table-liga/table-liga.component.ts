import { Component } from '@angular/core';

@Component({
  selector: 'app-table-liga',
  standalone: false,
  templateUrl: './table-liga.component.html'
})
export class TableLigaComponent {

}
