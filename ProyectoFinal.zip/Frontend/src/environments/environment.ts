export const environment = {
  baseURL: 'https://backendproyecto-final.onrender.com',
};
